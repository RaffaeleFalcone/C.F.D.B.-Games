package ServletUser;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Bean.*;
import DataModel.ProdottiDM;


public class GestioneProdotti extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static ProdottiDM model;

	public GestioneProdotti() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		model = new ProdottiDM();
		String action = request.getParameter("action");

		response.setContentType("text/html");
		String disponibilit� = request.getParameter("disponibilit�");

		if (disponibilit� == null || disponibilit� == "") {
			disponibilit� = "1";
		}

		int disponibili = Integer.parseInt(disponibilit�);

		if (disponibili < 1) {
			disponibili = 1;
		}

		if (action != null) {

			if (action.equalsIgnoreCase("showlist")) {
				UtenteBean user = (UtenteBean)request.getSession().getAttribute("user");
				try {
					Collection<ProdottiBean> collection = model.getAllProdotti(null, disponibili);
					
					while (collection.isEmpty()) {
						if (disponibili == 1) {
							break;
						}

						collection = model.getAllProdotti(null, disponibili -1);
					}
					request.setAttribute("collection", collection);
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				request.setAttribute("user", user);
				RequestDispatcher rd = getServletContext().getRequestDispatcher("/videogames.jsp?numberPage=" + disponibili);
				rd.forward(request, response);
			}

			else if (action.equalsIgnoreCase("search")) {
				String prod = request.getParameter("search");

				try {
					Collection<ProdottiBean> prodotti = model.searchProdottoDaTitolo(prod);
					request.setAttribute("prodotti", prodotti);
				} catch (SQLException e) {
					e.printStackTrace();
				}

				RequestDispatcher rd = getServletContext()
						.getRequestDispatcher("/prodottiRicerca.jsp?numberPage=" + disponibili);
				rd.forward(request, response);
			}

			else if (action.equalsIgnoreCase("addToCart")) {

				int codiceProdotto = Integer.parseInt(request.getParameter("codiceProdotto"));
				CarrelloBean cart = (CarrelloBean) request.getSession().getAttribute("cart");
				UtenteBean user = (UtenteBean) request.getSession().getAttribute("user");

				if (cart == null) {
					cart = new CarrelloBean(user.getNome());
				}

				ProdottiBean AggiungiAlCarrello = new ProdottiBean();

				try {
					AggiungiAlCarrello = model.searchProdottoByCodice(codiceProdotto);
				} catch (SQLException e) {
					e.printStackTrace();
				}

				cart.addProdottoBean(AggiungiAlCarrello);
				request.getSession().setAttribute("cart", cart);

				RequestDispatcher rd = getServletContext().getRequestDispatcher("/cart.jsp");
				rd.forward(request, response);

			}

			else if (action.equalsIgnoreCase("emptyCart")) {
				UtenteBean user=(UtenteBean) request.getSession().getAttribute("user");
				request.getSession().removeAttribute("cart");
				CarrelloBean cart = new CarrelloBean(user.getNome());
				request.getSession().setAttribute("cart", cart);

				RequestDispatcher rd = getServletContext().getRequestDispatcher("/cart.jsp");
				rd.forward(request, response);

			} else if (action.equals("deleteFromCart")) {

				CarrelloBean cart = (CarrelloBean) request.getSession().getAttribute("cart");
				int codiceProdotto = Integer.parseInt(request.getParameter("codiceProdotto"));

				try {
					ProdottiBean prodotto = model.searchProdottoByCodice(codiceProdotto);
					cart.deleteProdotti(prodotto);
					request.getSession().setAttribute("cart", cart);
				} catch (SQLException e) {
					e.printStackTrace();
				}

				RequestDispatcher rd = getServletContext().getRequestDispatcher("/cart.jsp");
				rd.forward(request, response);

			}

		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);

	}
}
