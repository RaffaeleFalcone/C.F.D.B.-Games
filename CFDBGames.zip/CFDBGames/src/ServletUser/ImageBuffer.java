package ServletUser;


import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

//import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BufferImage
 */

public class ImageBuffer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
    public ImageBuffer() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("image/png");
		String action = request.getParameter("action");
		InputStream imageStream = null;
		BufferedInputStream in = null;
		
		if(action != null){
			if(action.equalsIgnoreCase("getImage")){
				
				String pathImmagine = request.getParameter("pathImmagine");
				if(pathImmagine!=null && !pathImmagine.equals("") && !pathImmagine.equals("null")){
					
					try{
						response.setContentType("image/jpg");
						imageStream = new FileInputStream(pathImmagine);

						in = new BufferedInputStream(imageStream);
						int ch=0;

						while((ch=imageStream.read())!=-1){
							response.getOutputStream().write(ch);
						}
					
					}finally{
						response.getOutputStream().flush();
						response.getOutputStream().close();
						imageStream.close();
						in.close();
					}
				}
				
			}
			
		}
			
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

