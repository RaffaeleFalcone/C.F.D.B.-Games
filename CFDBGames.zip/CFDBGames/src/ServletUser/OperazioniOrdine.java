

package ServletUser;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.*;

import DataModel.OrderDM;


/**
 * Servlet implementation class OrdersOperations
 */

public class OperazioniOrdine extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private static OrderDM model = new OrderDM();
	
   
    public OperazioniOrdine() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String action = request.getParameter("action");
		CarrelloBean cart = (CarrelloBean) request.getSession().getAttribute("cart");
		boolean userLog = (boolean) request.getSession().getAttribute("userlog");
	
		String numberPageString= request.getParameter("numberPage");
		
		if(numberPageString==null || numberPageString==""){
			numberPageString="1";
		}
		
		int numberPage=Integer.parseInt(numberPageString);
		
		if(numberPage<1){
			numberPage=1;
		}
		
		if(userLog){
			if((action!= null)&&(!action.equals(""))){
				
		
				if(action.equalsIgnoreCase("insert")){	
					
					double totalCart=cart.getPrezzoTotale();
					
					int nMerci=cart.getCart().size();
					String dataOdierna=this.getDataOdierna();

					String mezzo=request.getParameter("mezzo");
					String metodoDiPagamento=request.getParameter("metodoDiPagamento");
					String numCard=request.getParameter("numCard");
					
					
					UtenteBean user = (UtenteBean)request.getSession().getAttribute("user");

					OrdineBean newOrder = new OrdineBean();

					newOrder.setDataOrdine(dataOdierna);
					newOrder.setMezzo(mezzo);
					newOrder.setnMerci(nMerci);
					newOrder.setTotale(totalCart);
					newOrder.setMetodoDiPagamento(metodoDiPagamento);
					newOrder.setNumCard(numCard);
					newOrder.setCodiceUtente(user.getCodiceUtente());
					try {
						model.insertNewOrder(newOrder);
						request.getSession().setAttribute("cart", new CarrelloBean((String)request.getSession().getAttribute("")));
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Collection<OrdineBean> allOrdersByUser;
					try {
						allOrdersByUser=model.searchByCodeUser(user.getCodiceUtente(), numberPage);
						while(allOrdersByUser.isEmpty()){
							if(numberPage==1){
								break;
							}
							allOrdersByUser=model.searchByCodeUser(user.getCodiceUtente(), numberPage-1);
						}
						
						request.setAttribute("allOrdersByUser", allOrdersByUser);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					RequestDispatcher rd=request.getRequestDispatcher("/Ordini.jsp?numberPage="+numberPage);  
					rd.forward(request,response);
					
				}
				
				
				
				else if(action.equalsIgnoreCase("getMyOrders")){
					Collection<OrdineBean> allOrdersByUser;
					UtenteBean user = (UtenteBean) request.getSession().getAttribute("user");
					try {
						allOrdersByUser=model.searchByCodeUser(user.getCodiceUtente(), numberPage);
						while(allOrdersByUser.isEmpty()){
							if(numberPage==1){
								break;
							}
							allOrdersByUser=model.searchByCodeUser(user.getCodiceUtente(), numberPage-1);
						}
						
						request.setAttribute("allOrdersByUser", allOrdersByUser);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					RequestDispatcher rd=request.getRequestDispatcher("/Ordini.jsp?numberPage="+numberPage);  
					rd.forward(request,response);
				}
			
		
				else{
					//action diverso dalle scelte preimpostate
					response.sendError(403);
				}

			}
			else{
				// action � uguale a null oppure a ""
				response.sendError(403);
			}
		}
		
		else {
			// l' utente non � loggato non pu� utilizzare la servlet
			response.sendError(401);
		}
		
	}	
		private String getDataOdierna(){
			Calendar dataodierna = Calendar.getInstance(); 
			// rilevo data 
			int mese_int = dataodierna.get(Calendar.MONTH);
			int anno_int = dataodierna.get(Calendar.YEAR);
			int giorno_int = dataodierna.get(Calendar.DAY_OF_MONTH);	
			String mese = new String(""+mese_int);
			String anno = new String(""+anno_int);
			String giorno = new String(""+giorno_int);
			
			return anno+"-"+mese+"-"+giorno;
		}
		
		
		
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	
	
}
