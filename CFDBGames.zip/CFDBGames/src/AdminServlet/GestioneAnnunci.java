package AdminServlet;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Collection;
import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import Bean.ProdottiBean;
import DataModel.ProdottiDM;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 5, maxFileSize = 1024 * 1024 * 50, maxRequestSize = 1024 * 1024 * 50)
public class GestioneAnnunci extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String SAVE_DIR = "";
	private static ProdottiDM model;

	public void init() {
		SAVE_DIR = getServletConfig().getInitParameter("file-upload");

	}

	public GestioneAnnunci() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		String action = (String) request.getParameter("action");
		model = new ProdottiDM();
		String disponibilit�String = (String) request.getParameter("disponibilit�");
		boolean adminlog = (boolean) request.getSession().getAttribute("adminlog");

		if (disponibilit�String == null || disponibilit�String == "") {
			disponibilit�String = "1";
		}

		int disponibilit� = Integer.parseInt(disponibilit�String);

		if (disponibilit� < 1) {
			disponibilit� = 1;
		}

		/* Controllo lato admin */
		if (adminlog) {

			if (action != null && action != "") {
				if (action.equalsIgnoreCase("showList")) {
					try {
						Collection<ProdottiBean> collection = model.getAllProdotti(null, disponibilit�);

						while (collection.size() == 1) {
							if (disponibilit� == 1) {
								break;
							}

							collection = model.getAllProdotti(null, disponibilit� - 1);
						}
						request.setAttribute("collection", collection);
					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					RequestDispatcher rd = getServletContext().getRequestDispatcher("/ListaProdotti.jsp?numberPage=" + disponibilit�);
					rd.forward(request, response);

				} 
				
				else if (action.equalsIgnoreCase("showListScontaGenere")) {
					try {
						String genere = (String) request.getParameter("genere");
						Collection<ProdottiBean> collection = (Collection<ProdottiBean>) model.getAllGameByGenere(genere);
						request.setAttribute("collection", collection);
					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					RequestDispatcher rd = getServletContext()
							.getRequestDispatcher("/ListaProdottoGenere.jsp?numberPage=1" );
					rd.forward(request, response);

				}
				else if (action.equalsIgnoreCase("insert")) {

					ProdottiBean prodotto = new ProdottiBean();
					String finalStringPath = null;

					String Titolo = request.getParameter("titolo");
					int codiceProdotto = Integer.parseInt(request.getParameter("CodiceProdotto"));
					String produttore = request.getParameter("produttore");
					int disponibilita = Integer.parseInt(request.getParameter("disponibilita"));
					String codicePegi = request.getParameter("codicePegi");
					String genere = request.getParameter("genere");
					String descrizione = request.getParameter("descrizione");
					double prezzo = Double.parseDouble(request.getParameter("prezzo"));

					Part part = request.getPart("image");

					if (part != null && part.getSize() != 0) {
						String savePath = request.getContextPath()+SAVE_DIR;
						InputStream in;
						File fileSavePath = new File(savePath);
						if (!fileSavePath.exists()) {
							fileSavePath.mkdirs();
						}
						String fileName = extractFileName(
								part); /*
										 * resistuisci il path completo
										 * dell'immagine
										 */
						fileName = fileName.substring(
								fileName.indexOf(File.separator, fileName.lastIndexOf(File.separator)) + 1,
								fileName.length());
						finalStringPath = savePath + File.separator + fileName;
						in = part.getInputStream();
						BufferedImage imagefinal = ImageIO.read(in);

						File out = new File(finalStringPath);
						ImageIO.write(imagefinal, "jpg", out);

					}

					prodotto.setCodiceProdotto(codiceProdotto);
					prodotto.setTitolo(Titolo);
					prodotto.setProduttore(produttore);
					prodotto.setDescrizione(descrizione);
					prodotto.setPrezzo(prezzo);
					prodotto.setDisponibilit�(disponibilita);
					prodotto.setGenere(genere);
					if (codicePegi.isEmpty() || codicePegi == "") {
						prodotto.setCodicePegi(null);
						;
					} else {
						prodotto.setCodicePegi(codicePegi);
					}

					prodotto.setImmagine(finalStringPath);

					try {
						model.insertNuovoProdotto(prodotto);
					} catch (SQLException e) {

						e.printStackTrace();
					}
					response.sendRedirect("GestioneAnnunci?action=showlist&numberPage=1");

				} else if (action.equalsIgnoreCase("delete")) {
					int codiceProdotto = Integer.parseInt(request.getParameter("CodiceProdotto"));

					try {
						model.deleteProdotto(codiceProdotto);

					} catch (SQLException e) {
						e.printStackTrace();
					}
					response.sendRedirect("GestioneAnnunci?action=showlist&numberPage=1");

				} else if (action.equalsIgnoreCase("redirectForUpdate")) {
					/*
					 * Bisogna lavorare su un solo elemento quindi si fa il
					 * redirect su altra pagina impostando quello che �
					 * l'oggetto nella sessione
					 */

					int codiceProdotto = Integer.parseInt(request.getParameter("CodiceProdotto"));

					try {
						ProdottiBean prodotto = model.searchProdottoByCodice(codiceProdotto);
						request.getSession().setAttribute("prodotto", prodotto);
						/* Redirict alla pagina di modifica */
						RequestDispatcher rd = getServletContext().getRequestDispatcher("/ModificaProdotto.jsp");
						rd.forward(request, response);
					} catch (SQLException e) {
						e.printStackTrace();
					}
					
				} 
				else if(action.equalsIgnoreCase("applicaSconto")){
				String finalStringPath = null;
				double prezzo = 0;
				int disponibilita = 0;
				ProdottiBean prodotto = new ProdottiBean();
				ProdottiBean prodottoDaAggiornare = (ProdottiBean) request.getSession().getAttribute("prodotto");
				int sconto= (int) request.getSession().getAttribute("sconto");
				String titolo = prodottoDaAggiornare.getTitolo();

				if (request.getParameter("disponibilita") != null
						|| !(request.getParameter("disponibilita").equals(""))
						|| !(request.getParameter("disponibilita").isEmpty())) {
					disponibilita = prodottoDaAggiornare.getDisponibilit�();

				}
				String produttore = prodottoDaAggiornare.getProduttore();
				String descrizione = prodottoDaAggiornare.getDescrizione();

				if (request.getParameter("prezzo") != null || !request.getParameter("prezzo").equals("")) {
					// eccezione empty string senza questo controllo
					prezzo = prezzo - ((prezzo*sconto)/100);
				}

				String codicePegi = request.getParameter("codicePegi");
				Part part = request.getPart("image");

				if (part != null && part.getSize() != 0) {
					String savePath = request.getServletContext().getRealPath("") + SAVE_DIR;
					InputStream in;
					File fileSavePath = new File(savePath);
					if (!fileSavePath.exists()) {
						fileSavePath.mkdirs();
					}
					String fileName = extractFileName(
							part); /*
									 * resistuisci il path completo
									 * dell'immagine
									 */
					fileName = fileName.substring(
							fileName.indexOf(File.separator, fileName.lastIndexOf(File.separator)) + 1,
							fileName.length());
					finalStringPath = savePath + File.separator + fileName;
					in = part.getInputStream();
					BufferedImage imagefinal = ImageIO.read(in);

					File out = new File(finalStringPath);
					ImageIO.write(imagefinal, "jpg", out);

					prodotto.setImmagine(finalStringPath);

				}

				else {
					prodotto.setImmagine(null);
				}
				if (disponibilita == 0) {
					disponibilita = prodottoDaAggiornare.getDisponibilit�();
				}
				if (titolo.equals("") || titolo == null) {
					titolo = prodottoDaAggiornare.getTitolo();
				}
				if (produttore.equals("") || produttore == null) {
					produttore = prodottoDaAggiornare.getProduttore();
				}
				if (descrizione.equals("") || descrizione == null) {
					descrizione = prodottoDaAggiornare.getDescrizione();
				}
				if (prezzo == 0) {
					prezzo = prodottoDaAggiornare.getPrezzo();
				}

				prodotto.setCodiceProdotto(prodottoDaAggiornare.getCodiceProdotto());
				prodotto.setTitolo(titolo);
				prodotto.setProduttore(produttore);
				prodotto.setDescrizione(descrizione);
				prodotto.setPrezzo(prezzo);
				prodotto.setCodicePegi(codicePegi);
				prodotto.setImmagine(finalStringPath);
				prodotto.setDisponibilit�(disponibilita);

				try {
					model.aggiornaProdotto(prodotto);
				} catch (SQLException e) {
					e.printStackTrace();
				}

				response.sendRedirect("GestioneAnnunci?action=showlist&numberPage=1");
					
				}
				
				else if(action.equalsIgnoreCase("applicaScontoPerGenere")){
					String sconto = request.getParameter("sconto");
					String genere = request.getParameter("genere");
					
					try {
						model.ScontaPerGenere(sconto,genere);
					
					} catch (SQLException e) {
						e.printStackTrace();
					}
					response.sendRedirect("GestioneAnnunci?action=showListScontaGenere&numberPage=1");
				}
				
				else if(action.equalsIgnoreCase("scontoProdotto")) {
					String codiceProdotto = request.getParameter("codiceProdotto");
					
					try {
						model.scontaProdotto(codiceProdotto);
					}
					catch(SQLException e) {
						e.printStackTrace();
					}
					response.sendRedirect("GestioneAnnunci?action=showList&numberPage=1");
				}
				
				else if (action.equalsIgnoreCase("aggiorna")) {
					String finalStringPath = null;
					double prezzo = 0;
					int disponibilita = 0;
					ProdottiBean prodotto = new ProdottiBean();
					ProdottiBean prodottoDaAggiornare = (ProdottiBean) request.getSession().getAttribute("prodotto");

					String titolo = request.getParameter("titolo");

					if (request.getParameter("disponibilita") != null
							|| !(request.getParameter("disponibilita").equals(""))
							|| !(request.getParameter("disponibilita").isEmpty())) {
						disponibilita = Integer.parseInt(request.getParameter("disponibilita"));

					}
					String produttore = request.getParameter("produttore");
					String descrizione = request.getParameter("descrizione");

					if (request.getParameter("prezzo") != null || !request.getParameter("prezzo").equals("")) {
						// eccezione empty string senza questo controllo
						prezzo = Double.parseDouble(request.getParameter("prezzo"));
					}

					String codicePegi = request.getParameter("codicePegi");
					Part part = request.getPart("image");

					if (part != null && part.getSize() != 0) {
						String savePath = request.getServletContext().getRealPath("") + SAVE_DIR;
						InputStream in;
						File fileSavePath = new File(savePath);
						if (!fileSavePath.exists()) {
							fileSavePath.mkdirs();
						}
						String fileName = extractFileName(
								part); /*
										 * resistuisci il path completo
										 * dell'immagine
										 */
						fileName = fileName.substring(
								fileName.indexOf(File.separator, fileName.lastIndexOf(File.separator)) + 1,
								fileName.length());
						finalStringPath = savePath + File.separator + fileName;
						in = part.getInputStream();
						BufferedImage imagefinal = ImageIO.read(in);

						File out = new File(finalStringPath);
						ImageIO.write(imagefinal, "jpg", out);

						prodotto.setImmagine(finalStringPath);

					}

					else {
						prodotto.setImmagine(null);
					}
					if (disponibilita == 0) {
						disponibilita = prodottoDaAggiornare.getDisponibilit�();
					}
					if (titolo.equals("") || titolo == null) {
						titolo = prodottoDaAggiornare.getTitolo();
					}
					if (produttore.equals("") || produttore == null) {
						produttore = prodottoDaAggiornare.getProduttore();
					}
					if (descrizione.equals("") || descrizione == null) {
						descrizione = prodottoDaAggiornare.getDescrizione();
					}
					if (prezzo == 0) {
						prezzo = prodottoDaAggiornare.getPrezzo();
					}

					prodotto.setCodiceProdotto(prodottoDaAggiornare.getCodiceProdotto());
					prodotto.setTitolo(titolo);
					prodotto.setProduttore(produttore);
					prodotto.setDescrizione(descrizione);
					prodotto.setPrezzo(prezzo);
					prodotto.setCodicePegi(codicePegi);
					prodotto.setImmagine(finalStringPath);
					prodotto.setDisponibilit�(disponibilita);

					try {
						model.aggiornaProdotto(prodotto);
					} catch (SQLException e) {
						e.printStackTrace();
					}

					response.sendRedirect("GestioneAnnunci?action=showlist&numberPage=1");
				} else {
					// action diverso dalle scelte preimpostate
					response.sendError(403);
				}
			} else {
				// action � uguale a null oppure a ""
				response.sendError(403);
			}

		} else {
			// non sei admin
			response.sendError(401);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	private String extractFileName(Part part) {

		String game = part.getHeader("content-disposition");
		String[] items = game.split(";");

		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}

}

