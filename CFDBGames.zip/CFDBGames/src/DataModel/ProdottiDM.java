package DataModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import Bean.ProdottiBean;

import ControllerDB.DriverManagerConnectionPool;

public class ProdottiDM {

	private final static String TABLE_NAME = "DatabaseMod.Prodotti";

	public synchronized Collection<ProdottiBean> getAllGames(String order, int disponibilit�) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<ProdottiBean> games = new LinkedList<ProdottiBean>();

		String getAllGamesSql = "SELECT * FROM " + ProdottiDM.TABLE_NAME;

		if (order != null) {
			getAllGamesSql += " ORDER BY " + order;
		}

		getAllGamesSql += " LIMIT 9 OFFSET " + ((disponibilit� * 9) - 9);
		try {

			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(getAllGamesSql);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {

				if (rs.getInt("CodiceProdotto") == 0) {
					ProdottiBean game = new ProdottiBean();
					game.setCodiceProdotto(rs.getInt("CodiceProdotto"));
					game.setPrezzo(rs.getDouble("Prezzo"));
					game.setDisponibilit�(rs.getInt("Disponibilita"));
					game.setTitolo(rs.getString("Titolo"));
					game.setProduttore(rs.getString("Produttore"));
					game.setCodicePegi(rs.getString("CodicePegi"));
					game.setGenere(rs.getString("Genere"));
					game.setImmagine(rs.getString("Immagine"));
					game.setDescrizione(rs.getString("Descrizione"));
					game.setCodiceOrdine(rs.getInt("CODICE_ORDINE"));
					games.add(game);
				}
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}

		}
		return games;
	}
	
	
	public synchronized Collection<ProdottiBean> searchProdottoDaTitolo(String title) throws SQLException {
		Collection<ProdottiBean> prodotti = new LinkedList<ProdottiBean>();
		ProdottiBean prodotto = new ProdottiBean();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM " + TABLE_NAME + " WHERE Titolo = ? ";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, title);
			rs = preparedStatement.executeQuery();

			if (rs.next()) {
				prodotto.setCodiceProdotto(rs.getInt("CodiceProdotto"));
				prodotto.setPrezzo(rs.getInt("Prezzo"));
				prodotto.setDisponibilit�(rs.getInt("Disponibilita"));
				prodotto.setTitolo(rs.getString("Titolo"));
				prodotto.setProduttore(rs.getString("Produttore"));
				prodotto.setCodicePegi(rs.getString("CodicePegi"));
				prodotto.setGenere(rs.getString("Genere"));
				prodotto.setImmagine(rs.getString("Immagine"));
				prodotto.setDescrizione(rs.getString("Descrizione"));
				prodotto.setCodiceOrdine(rs.getInt("CODICE_ORDINE"));
				prodotti.add(prodotto);
			}

		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}

		}

		return prodotti;
	}

	public synchronized Collection<ProdottiBean> getAllProdotti(String order, int disponibilit�) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Collection<ProdottiBean> listaProdotti = new LinkedList<ProdottiBean>();
		ProdottiBean prodotto;
		ResultSet rs = null;
		String getAllProdottiSql = "SELECT * FROM " + TABLE_NAME;

		if (order != null) {
			getAllProdottiSql += " ORDER BY " + order;
		}

		getAllProdottiSql += " LIMIT 9 OFFSET " + ((disponibilit� * 9) - 9);

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(getAllProdottiSql);

			rs = preparedStatement.executeQuery();

			while (rs.next()) {
				prodotto = new ProdottiBean();
				prodotto.setCodiceProdotto(rs.getInt("CodiceProdotto"));
				prodotto.setPrezzo(rs.getDouble("Prezzo"));
				prodotto.setDisponibilit�(rs.getInt("Disponibilita"));
				prodotto.setTitolo(rs.getString("Titolo"));
				prodotto.setProduttore(rs.getString("Produttore"));
				prodotto.setCodicePegi(rs.getString("CodicePegi"));
				prodotto.setGenere(rs.getString("Genere"));
				prodotto.setImmagine(rs.getString("Immagine"));
				prodotto.setDescrizione(rs.getString("Descrizione"));
				prodotto.setCodiceOrdine(rs.getInt("CODICE_ORDINE"));
				listaProdotti.add(prodotto);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}

		}
		return listaProdotti;
	}

	public synchronized ProdottiBean searchProdottoByCodice(int codiceProdotto) throws SQLException {
		ProdottiBean prodotto = new ProdottiBean();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM " + TABLE_NAME + " WHERE CodiceProdotto = ? ";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, codiceProdotto);
			rs = preparedStatement.executeQuery();

			if (rs.next()) {
				prodotto.setCodiceProdotto(rs.getInt("CodiceProdotto"));
				prodotto.setPrezzo(rs.getInt("Prezzo"));
				prodotto.setDisponibilit�(rs.getInt("Disponibilita"));
				prodotto.setTitolo(rs.getString("Titolo"));
				prodotto.setProduttore(rs.getString("Produttore"));
				prodotto.setCodicePegi(rs.getString("CodicePegi"));
				prodotto.setGenere(rs.getString("Genere"));
				prodotto.setImmagine(rs.getString("Immagine"));
				prodotto.setDescrizione(rs.getString("Descrizione"));
				prodotto.setCodiceOrdine(rs.getInt("CODICE_ORDINE"));
			}

		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}

		}

		return prodotto;
	}
	
	public synchronized Collection <ProdottiBean> getAllGameByGenere(String genere) throws SQLException {
		Collection<ProdottiBean> listaProdotti = new LinkedList<ProdottiBean>();
		ProdottiBean prodotto;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM " + TABLE_NAME + " WHERE genere = ? ";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, genere);
			rs = preparedStatement.executeQuery();

			while (rs.next()) {
				prodotto = new ProdottiBean();
				prodotto.setCodiceProdotto(rs.getInt("CodiceProdotto"));
				prodotto.setPrezzo(rs.getInt("Prezzo"));
				prodotto.setDisponibilit�(rs.getInt("Disponibilita"));
				prodotto.setTitolo(rs.getString("Titolo"));
				prodotto.setProduttore(rs.getString("Produttore"));
				prodotto.setCodicePegi(rs.getString("CodicePegi"));
				prodotto.setGenere(rs.getString("Genere"));
				prodotto.setImmagine(rs.getString("Immagine"));
				prodotto.setDescrizione(rs.getString("Descrizione"));
				prodotto.setCodiceOrdine(rs.getInt("CODICE_ORDINE"));
				listaProdotti.add(prodotto);
			}

		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}

		}

		return listaProdotti;
	}

	public synchronized void insertNuovoProdotto(ProdottiBean prodotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String sqlInsert = "INSERT INTO " + TABLE_NAME
				+ "(CodiceProdotto,Prezzo,Disponibilita,Titolo,Produttore,CodicePegi,Genere,Immagine,Descrizione)VALUES(?,?,?,?,?,?,?,?,?)";
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(sqlInsert);
			preparedStatement.setInt(1, prodotto.getCodiceProdotto());
			preparedStatement.setDouble(2, prodotto.getPrezzo());
			preparedStatement.setInt(3, prodotto.getDisponibilit�());
			preparedStatement.setString(4, prodotto.getTitolo());
			preparedStatement.setString(5, prodotto.getProduttore());
			preparedStatement.setString(6, prodotto.getCodicePegi());
			preparedStatement.setString(7, prodotto.getGenere());
			preparedStatement.setString(8, prodotto.getImmagine());
			preparedStatement.setString(9, prodotto.getDescrizione());

			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	public synchronized boolean deleteProdotto(int codiceProdotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int rs = 0;

		String deleteSQL = "DELETE FROM " + TABLE_NAME + " WHERE CodiceProdotto=?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, codiceProdotto);
			rs = preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}

		}

		return (rs != 0);
	}
	
	public synchronized  void ScontaPerGenere(String sconto, String genere) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String updateSQL = "UPDATE " + TABLE_NAME + " SET prezzo = prezzo - (prezzo * " + sconto +") / 100 WHERE genere = ?";

		try{
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement= connection.prepareStatement(updateSQL);
			preparedStatement.setString(1, genere);
			preparedStatement.executeUpdate();
			connection.commit();
	
				
		} finally {

			try {
				if (connection != null) {
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

	}
	
	public synchronized  void scontaProdotto(String codice) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String updateSQL = "UPDATE " + TABLE_NAME + " SET prezzo = prezzo - (prezzo * 50) / 100 WHERE CodiceProdotto = ?";

		try{
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement= connection.prepareStatement(updateSQL);
			preparedStatement.setString(1, codice);
			preparedStatement.executeUpdate();
			connection.commit();
	
				
		} finally {

			try {
				if (connection != null) {
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

	}

	public synchronized void aggiornaProdotto(ProdottiBean prodotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String updateSQL = "UPDATE " + TABLE_NAME
				+ " SET Prezzo=?, Disponibilita=?, Titolo=?, Produttore=?, CodicePegi=?, Genere=?,Immagine=?, Descrizione=? WHERE CodiceProdotto=?";
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(updateSQL);

			preparedStatement.setDouble(1, prodotto.getPrezzo());
			preparedStatement.setInt(2, prodotto.getDisponibilit�());
			preparedStatement.setString(3, prodotto.getTitolo());
			preparedStatement.setString(4, prodotto.getProduttore());
			preparedStatement.setString(5, prodotto.getCodicePegi());
			preparedStatement.setString(6, prodotto.getGenere());
			preparedStatement.setString(7, prodotto.getImmagine());
			preparedStatement.setString(8, prodotto.getDescrizione());
			preparedStatement.setInt(9, prodotto.getCodiceProdotto());

			preparedStatement.executeUpdate();
			connection.commit();
		} finally {

			try {
				if (connection != null) {
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

	}

}