package Bean;

import java.util.ArrayList;
import java.util.List;

import Bean.ProdottiBean;;

public class CarrelloBean {

	private List<ProdottiBean> prodotti;
	private String idPropietario;
	private int numeroProdotti;
	private int prezzoTotale;

	public CarrelloBean(String idPropietario) {
		this.prodotti = new ArrayList<ProdottiBean>();
		this.idPropietario = idPropietario;
		this.numeroProdotti = prodotti.size();
		for (int i = 0; i < prodotti.size(); i++) {
			prezzoTotale = prezzoTotale += prodotti.get(i).getPrezzo();
		}

	}

	public void addProdottoBean(ProdottiBean product) {
		prodotti.add(product);
		prezzoTotale += product.getPrezzo();
	}

	public void deleteProdotti(ProdottiBean product) {
		for (ProdottiBean prod : prodotti) {
			if (prod.getCodiceProdotto() == product.getCodiceProdotto()) {
				prodotti.remove(prod);
				break;
			}
		}
	}

	public boolean ProdottoPresente(ProdottiBean product) {
		for (ProdottiBean prod : prodotti) {
			if (prod.getCodiceProdotto() == product.getCodiceProdotto()) {
				return true;
			}
		}
		return false;
	}

	public List<ProdottiBean> getProducts() {
		return prodotti;
	}

	public void setProdotti(List<ProdottiBean> products) {
		this.prodotti = products;
	}

	public String getIdPropietario() {
		return idPropietario;
	}

	public void setIdPropietario(String idPropietario) {
		this.idPropietario = idPropietario;
	}

	public int getNumeroProdotti() {
		return numeroProdotti;
	}

	public void setNumeroProdotti(int numeroProdotti) {
		this.numeroProdotti = numeroProdotti;
	}

	public int getPrezzoTotale() {
		return prezzoTotale;
	}

	public void setPrezzoTotale(int prezzoTotale) {
		this.prezzoTotale = prezzoTotale;
	}

	public List<ProdottiBean> getCart() {
		return prodotti;
	}

}
