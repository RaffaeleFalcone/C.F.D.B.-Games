package Bean;

public class ProdottiBean {
	int CodiceProdotto;
	int Disponibilit�;
	double prezzo;
	String codicePegi;
	String titolo;
	String genere;
	String produttore;
	String immagine;
	String Descrizione;
	int codiceOrdine;

	public ProdottiBean() {
		this.CodiceProdotto = 000000000;
		this.Disponibilit� = 0;
		this.genere = "";
		this.prezzo = 0;
		this.codicePegi = "";
		this.Descrizione = "";
		this.titolo = "";
		this.produttore = "";
		this.immagine = "";
		this.codiceOrdine = 0;
	}

	public String getGenere() {
		return genere;
	}

	public void setGenere(String genere) {
		this.genere = genere;
	}

	public int getCodiceProdotto() {
		return CodiceProdotto;
	}

	public void setCodiceProdotto(int codiceProdotto) {
		CodiceProdotto = codiceProdotto;
	}

	public int getDisponibilit�() {
		return Disponibilit�;
	}

	public void setDisponibilit�(int disponibilit�) {
		Disponibilit� = disponibilit�;
	}

	public double getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(int prezzo) {
		this.prezzo = prezzo;
	}

	public String getCodicePegi() {
		return codicePegi;
	}

	public void setCodicePegi(String codicePegi) {
		this.codicePegi = codicePegi;
	}

	public String getDescrizione() {
		return Descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.Descrizione = descrizione;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getProduttore() {
		return produttore;
	}

	public void setProduttore(String produttore) {
		this.produttore = produttore;
	}

	public String getImmagine() {
		return immagine;
	}

	public void setImmagine(String immagine) {
		this.immagine = immagine;
	}

	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}

	public int getCodiceOrdine() {
		return codiceOrdine;
	}

	public void setCodiceOrdine(int codiceOrdine) {
		this.codiceOrdine = codiceOrdine;
	}

}
