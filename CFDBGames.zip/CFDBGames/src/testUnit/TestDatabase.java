package testUnit;

import java.sql.*;
import java.util.*;

import Bean.OrdineBean;
import Bean.ProdottiBean;
import Bean.UtenteBean;


import DataModel.*;

public class TestDatabase {
	private static OrderDM model = new OrderDM();
	public void testInsertNewOrder(){
		OrdineBean ordine = new OrdineBean();
		ordine.setCodiceOrdine(1);
		ordine.setCodiceUtente(1);
		ordine.setDataOrdine("22/12/02");
		ordine.setMetodoDiPagamento("carta");
		ordine.setMezzo("aereo");
		ordine.setnMerci(1);
		ordine.setNumCard("123456789");
		try {
			model.insertNewOrder(ordine);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void TestGetMyOrders(){
		Collection<OrdineBean> allOrdersByUser;
		UtenteBean user= new UtenteBean();
		user.setCodiceUtente(1);
		try {
			allOrdersByUser=model.searchByCodeUser(user.getCodiceUtente(),1);
			System.out.println(allOrdersByUser);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static ProdottiDM model1 = new ProdottiDM();
	public void TestSearchProdottoDaTitolo(){
	try {
		Collection<ProdottiBean> prodotti =model1.searchProdottoDaTitolo("UnTitolo");
		System.out.println(prodotti);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	
	public void TestGetAllProdotti(){
		try {
			Collection<ProdottiBean> collection = model1.getAllProdotti(null, 1);
			
			System.out.println(collection);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

	public void TestSearchProdottoByCodice(){
		try {
			ProdottiBean prodotto = model1.searchProdottoByCodice(1);
			System.out.println(prodotto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void TestGetAllGameByGenere(){
		try {
			Collection<ProdottiBean> prodotti = model1.getAllGameByGenere("fps");
			System.out.println(prodotti);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void TestInsertNuovoProdotto(){
		ProdottiBean prodotto = new ProdottiBean();
		prodotto.setCodiceOrdine(1);
		prodotto.setCodicePegi("12+");
		prodotto.setCodiceProdotto(3);
		prodotto.setDescrizione("blalala");
		prodotto.setDisponibilit�(12);
		prodotto.setGenere("fps");
		prodotto.setImmagine("frefrfreferh9");
		prodotto.setPrezzo(1);
		prodotto.setProduttore("unProduttore");
		prodotto.setTitolo("UnTitolo");
		
		try {
			model1.insertNuovoProdotto(prodotto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void TestDeleteProdotto(){
		try {
			model1.deleteProdotto(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void TestScontaPerGenre(){
		try {
			model1.ScontaPerGenere("12", "fps");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void TestScontaProdotto(){
		try {
			model1.scontaProdotto("1");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static UtenteDM model2 = new UtenteDM();

	public void TestInsertUtente(){
		UtenteBean user = new UtenteBean();
		user.setNome("Carmine");
		user.setCognome("Giugliano");
		user.setCodiceUtente(15);
		user.setCitta("Sarno");
		user.setEmail("carmnine.95@hotmail.it");
		user.setN_civico(2);
		user.setVia("via roma");
		user.setUsername("username");
		user.setPass("12345");
		try {
			model2.insertUser(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void TestCancellaUtente(){
		try {
			model2.deleteUser(2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void TestUpdateUser(){
		
		UtenteBean user = new UtenteBean();
		user.setNome("Carmine");
		user.setCognome("Giugliano");
		user.setCodiceUtente(15);
		user.setCitta("Sarno");
		user.setEmail("carmnine.95@hotmail.it");
		user.setN_civico(2);
		user.setVia("via roma");
		user.setUsername("username");
		user.setPass("12345");
		
		try {
			model2.updateUser(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void TestCercaUtente(){
		try {
			model2.searchUser("username");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void TestGetUser(){
		Collection<UtenteBean> user;
		try {
			user = model2.getUsers(1);
			System.out.println(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}