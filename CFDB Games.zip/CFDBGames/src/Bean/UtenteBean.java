package Bean;


public class UtenteBean {
	int CodiceUtente;
	String Nome;
	String Cognome;
	String email;
	String via; 
	int n_civico;
	String citta;
	String username;
	String pass;



public UtenteBean() {
	this.CodiceUtente = 0 ;
	this.Nome = "";
	this.Cognome="";
	this.email="";
	this.via="";
	this.n_civico=0;
	this.citta="";
	this.username="";
	this.pass="";
	
}



public int getCodiceUtente() {
	return CodiceUtente;
}



public void setCodiceUtente(int codiceUtente) {
	CodiceUtente = codiceUtente;
}



public String getNome() {
	return Nome;
}



public void setNome(String nome) {
	Nome = nome;
}



public String getCognome() {
	return Cognome;
}



public void setCognome(String cognome) {
	Cognome = cognome;
}



public String getEmail() {
	return email;
}



public void setEmail(String email) {
	this.email = email;
}



public String getVia() {
	return via;
}



public void setVia(String via) {
	this.via = via;
}



public int getN_civico() {
	return n_civico;
}



public void setN_civico(int n_civico) {
	this.n_civico = n_civico;
}



public String getCitta() {
	return citta;
}



public void setCitta(String citta) {
	this.citta = citta;
}



public String getUsername() {
	return username;
}



public void setUsername(String username) {
	this.username = username;
}



public String getPass() {
	return pass;
}



public void setPass(String pass) {
	this.pass = pass;
}






}