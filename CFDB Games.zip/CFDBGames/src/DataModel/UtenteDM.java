package DataModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import Bean.UtenteBean;
import ControllerDB.DriverManagerConnectionPool;





public class UtenteDM {
	
	private final static String TABLE_NAME="utente";
	
	
	
	/* Inserimento Utente */
	
	public synchronized void insertUser(UtenteBean newUser) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
String registrazione = "INSERT INTO "+TABLE_NAME+"(Nome,Cognome, email, via, n_civico,citta, username, pass)"+" VALUES (?,?,?,?,?,?,?,?)";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(registrazione);
			//;
			preparedStatement.setString(1, newUser.getNome());
			preparedStatement.setString(2, newUser.getCognome() );
			preparedStatement.setString(3, newUser.getEmail());
			preparedStatement.setString(4, newUser.getVia());
			preparedStatement.setLong  (5, newUser.getN_civico());
			preparedStatement.setString(6, newUser.getCitta());
			preparedStatement.setString(7, newUser.getUsername());
			preparedStatement.setString(8, newUser.getPass() );
	
			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	
	/* Fine Registrazione */
	
	
	//cancella utente
	public synchronized boolean deleteUser(int CodiceUtente) throws SQLException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int rs = 0;
		String deleteSQL = " DELETE FROM "+TABLE_NAME+" WHERE CodiceUtente = ?";
	
		if(CodiceUtente != 0){ 
			try {
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(deleteSQL);
				preparedStatement.setInt(1,CodiceUtente);
				rs=preparedStatement.executeUpdate();
				
				connection.commit();		
			} finally {
				try{
					if(connection!=null){
						connection.close();
					}
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}

			}
			return (rs!=0);
		}
		return false;
	}

//aggiorna utente
	public synchronized void updateUser(UtenteBean user) throws SQLException{
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	
	String updateSQL = "UPDATE "+TABLE_NAME+" SET  CodiceUtente = ?, Nome= ?, Cognome= ?, email= ?, via=?, n_civico=?, citta=? , username=? , pass=?  WHERE CodiceUtente=?";
	
	try {
		connection = DriverManagerConnectionPool.getConnection();
		preparedStatement = connection.prepareStatement(updateSQL);
		
		
		preparedStatement.setInt(1, user.getCodiceUtente());
		preparedStatement.setString(2, user.getNome());
		preparedStatement.setString(3, user.getCognome());
		preparedStatement.setString(4, user.getEmail());
		preparedStatement.setString(5, user.getVia());
		preparedStatement.setInt(6, user.getN_civico());
		preparedStatement.setString(7, user.getCitta());
		preparedStatement.setString(8, user.getUsername()) ;
		preparedStatement.setString(9, user.getPass());
		preparedStatement.setInt(10, user.getCodiceUtente());
		
		preparedStatement.executeUpdate();
		connection.commit();
	} finally {
		try {
			if (preparedStatement != null)
				preparedStatement.close();
		} finally {
			DriverManagerConnectionPool.releaseConnection(connection);
		}
	}
	
}

//cerca utente
	public synchronized UtenteBean searchUser(String username) throws SQLException{
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	UtenteBean user = new UtenteBean();
	
	String selectSQL = "SELECT * FROM "+TABLE_NAME+" WHERE username = ?";
	try {
		connection = DriverManagerConnectionPool.getConnection();
		preparedStatement = connection.prepareStatement(selectSQL);
		preparedStatement.setString(1, username );
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {
			user.setCodiceUtente(rs.getInt("CodiceUtente"));
			user.setNome(rs.getString("Nome"));
		    user.setCognome(rs.getString("Cognome"));
			user.setEmail(rs.getString("email"));
			user.setVia(rs.getString("via"));
			user.setN_civico(rs.getInt("n_civico"));
			user.setCitta(rs.getString("citta"));
			user.setUsername(rs.getString("username"));
			user.setPass(rs.getString("pass"));
		}

	} finally {
		try {
			if (preparedStatement != null)
				preparedStatement.close();
		} finally {
			DriverManagerConnectionPool.releaseConnection(connection);
		}
	}
	return user;
	}

	
	
//pagine ricerca
public Collection<UtenteBean> getUsers(int numberPage)throws SQLException{
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	UtenteBean user = null;
	ResultSet rs = null;
	Collection<UtenteBean> allUser = new LinkedList<UtenteBean>();
	 
	String selectSQL = "SELECT * FROM "+TABLE_NAME+" ORDER BY CodiceUtente";
	selectSQL += " LIMIT 9 OFFSET "+((numberPage*9)-9);
	
	try {
		connection = DriverManagerConnectionPool.getConnection();
		preparedStatement = connection.prepareStatement(selectSQL);
		rs = preparedStatement.executeQuery();

		while (rs.next()) {
			user = new UtenteBean();
			user.setCodiceUtente(rs.getInt("CodiceUtente"));
			user.setNome(rs.getString("Nome"));
		    user.setCognome(rs.getString("Cognome"));
			user.setEmail(rs.getString("email"));
			user.setVia(rs.getString("via"));
			user.setN_civico(rs.getInt("n_civico"));
			user.setCitta(rs.getString("citta"));
			user.setUsername(rs.getString("username"));
			user.setPass(rs.getString("pass"));
			allUser.add(user);
		}

	} finally {
		try {
			if (preparedStatement != null)
				preparedStatement.close();
		} finally {
			DriverManagerConnectionPool.releaseConnection(connection);
		}
	}
	
	
	return allUser;
	
}


}

