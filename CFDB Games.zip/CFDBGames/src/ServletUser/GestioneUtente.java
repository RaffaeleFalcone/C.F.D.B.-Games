package ServletUser;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.UtenteBean;
import DataModel.UtenteDM;

/**
 * Servlet implementation class GestioneUtente
 */

public class GestioneUtente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	private static UtenteDM model = new UtenteDM();

	public GestioneUtente() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		String action = request.getParameter("action");

		if (action != null) {

			if (action.equals("insert")) {
				String Nome = request.getParameter("Nome");
				String Cognome = request.getParameter("Cognome");
				String email = request.getParameter("email");
				String username = request.getParameter("username");
				String pass = request.getParameter("pass");
				String citta = request.getParameter("citta");
				String via = request.getParameter("via");
				int numero_civico = Integer.parseInt(request.getParameter("numero_civico"));

				UtenteBean utente = new UtenteBean();

				utente.setNome(Nome);
				utente.setCognome(Cognome);
				utente.setEmail(email);
				utente.setUsername(username);
				utente.setPass(pass);
				utente.setCitta(citta);
				utente.setVia(via);
				utente.setN_civico(numero_civico);
				try {
					model.insertUser(utente);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Home.jsp");
				dispatcher.forward(request, response);
			}

			if (action.equalsIgnoreCase("login")) {

				String id = request.getParameter("id");
				String password = request.getParameter("password");
				UtenteBean user = new UtenteBean();
				try {
					user = model.searchUser(id);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// se l'utente esiste... controllo se le password coincidono
				if (!(user.getCodiceUtente() == 0)) {
					if (user.getPass().equals(password)) {
						request.getSession().setAttribute("user", user);
						request.getSession().setAttribute("userlog", true);
						request.getSession().setAttribute("username", user.getUsername());

						// controllo se � amministratore
						if (user.getUsername().equals("admin")) {
							request.getSession().setAttribute("adminlog", true);
							RequestDispatcher rd = request.getRequestDispatcher("/AreaAdmin.jsp");
							rd.forward(request, response);
						} else {// se non � amministratore e il nome utente e la
								// password sono validi effetua il login come
								// utente
							request.getSession().setAttribute("adminlog", false);
							request.getSession().setAttribute("user", user);
							RequestDispatcher rd = request.getRequestDispatcher("/AreaUtente.jsp");
							rd.forward(request, response);
						}

					} else {
						request.getSession().setAttribute("userlog", false);
						request.getSession().setAttribute("adminlog", false);
						RequestDispatcher rd = request.getRequestDispatcher("/Home.jsp");
						rd.forward(request, response);
					}
				}

				// nessun user con quel id trovato
				else {
					request.getSession().setAttribute("userlog", false);
					request.getSession().setAttribute("adminlog", false);
					RequestDispatcher rd = request.getRequestDispatcher("/Home.jsp");
					rd.forward(request, response);

				}
			}
		}
		if (action.equalsIgnoreCase("logout")) {

			request.getSession().setAttribute("user", new UtenteBean());
			request.getSession().setAttribute("userlog", false);
			request.getSession().setAttribute("adminlog", false);
			request.getSession().invalidate();
			RequestDispatcher rd = request.getRequestDispatcher("/Home.jsp");
			rd.forward(request, response);

		}

		if (action.equalsIgnoreCase("redirectForUpdate")) {
			UtenteBean user = (UtenteBean) request.getSession().getAttribute("user");

			try {
				model.searchUser(user.getUsername());
				request.getSession().setAttribute("user", user);
				RequestDispatcher rd = request.getRequestDispatcher("/ImpostazioniUtente.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		if (action.equalsIgnoreCase("aggiornaUtente")) {
			UtenteBean olduser = (UtenteBean) request.getSession().getAttribute("user");
			UtenteBean user = new UtenteBean();
			UtenteBean controlloPass;
			try {
				controlloPass = model.searchUser(olduser.getUsername());
				if (controlloPass.getPass() != request.getParameter("oldPass")) {

				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			user.setCodiceUtente(olduser.getCodiceUtente());
			user.setNome(olduser.getNome());
			user.setCognome(olduser.getCognome());
			user.setEmail(request.getParameter("email"));
			user.setVia(olduser.getVia());
			user.setN_civico(olduser.getN_civico());
			user.setCitta(olduser.getCitta());
			user.setUsername(olduser.getUsername());
			user.setPass(request.getParameter("newPass"));

			if (request.getParameter("email").isEmpty() || request.getParameter("email") == "")
				user.setEmail(olduser.getEmail());
			
			if (request.getParameter("newPass").isEmpty() || request.getParameter("newPass") == "")
				user.setPass(olduser.getPass());

			try {
				model.updateUser(user);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
			if (olduser.getPass() != user.getPass()) {
				RequestDispatcher rd = request.getRequestDispatcher("/AreaUtente.jsp");
				rd.forward(request, response);
			}

			else {
				RequestDispatcher rd = request.getRequestDispatcher("/ImpostazioniUtente.jsp");
				rd.forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
