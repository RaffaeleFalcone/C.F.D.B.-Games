DROP DATABASE IF EXISTS DatabaseMod;
CREATE DATABASE DatabaseMod;

USE DatabaseMod;
GRANT ALL PRIVILEGES ON DatabaseMod.* TO 'DatabaseMod'@'%' IDENTIFIED BY 'DatabaseMod';

DROP TABLE IF EXISTS utente;
CREATE TABLE utente (

CodiceUtente INT AUTO_INCREMENT NOT NULL,
Nome VARCHAR(25) ,
Cognome VARCHAR(25) ,
email VARCHAR(30) ,
via VARCHAR(30) ,
n_civico INT(3) ,
citta VARCHAR(30) ,
username VARCHAR(30) NOT NULL,
pass VARCHAR(30) NOT NULL,

PRIMARY KEY ( CodiceUtente) );


CREATE TABLE Ordine (
CODICE_ORDINE INT primary key AUTO_INCREMENT,
DATAORDINE Date,
MEZZO VARCHAR(45),
NMERCI INT(5),
TOTALE DECIMAL(8,2),
METODODIPAGAMENTO VARCHAR(25),
NUMCARD INT(16),
CodiceUtente INT,
FOREIGN KEY (CodiceUtente) REFERENCES utente(CodiceUtente) );


CREATE TABLE Prodotti (
CodiceProdotto INT NOT NULL,
Prezzo DECIMAL(8,2),
Disponibilita INT(10),
Titolo VARCHAR(100),
Produttore VARCHAR(25),
CodicePegi VARCHAR(10),
Genere VARCHAR(25),
Immagine VARCHAR(100),
Descrizione VARCHAR(100),
CODICE_ORDINE INT DEFAULT 0 NOT NULL,
PRIMARY KEY  (CodiceProdotto) );

INSERT INTO utente VALUES (1,'admin','admin','ad@ad.it','ad',4,'ad','admin','admin');

INSERT INTO utente VALUES (2,'ad','ad','ad@ad.it','ad',4,'ad','ad','ad');
INSERT INTO Prodotti VALUES (5,'12.80',10,'Call Of Duty','Activision','12+','Guerra','/Users/Expert/Documents/Call.jpg','aaa',DEFAULT);
INSERT INTO Prodotti VALUES (6,'30.50',10,'Prince of persia','Activision','12+','aaa','/Users/Expert/Documents/prince.jpg','aaa',DEFAULT);