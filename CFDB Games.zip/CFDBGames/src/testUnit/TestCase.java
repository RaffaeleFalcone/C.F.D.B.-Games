package testUnit;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.Collection;


import org.junit.Test;

import Bean.OrdineBean;
import Bean.ProdottiBean;
import Bean.UtenteBean;
import DataModel.OrderDM;
import DataModel.ProdottiDM;


public class TestCase {

	@Test
	public void testInsertNewOrder(){
		OrderDM model = new OrderDM();
		OrdineBean ordine = new OrdineBean();
		ordine.setCodiceOrdine(1);
		ordine.setCodiceUtente(1);
		ordine.setDataOrdine("22/12/02");
		ordine.setMetodoDiPagamento("carta");
		ordine.setMezzo("aereo");
		ordine.setnMerci(1);
		ordine.setNumCard("123456789");
		try {
			model.insertNewOrder(ordine);
			assertEquals(1, ordine.getCodiceOrdine());

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	@Test
	public void testMyOrder(){
	OrderDM model = new OrderDM();
	
	Collection<OrdineBean> allOrdersByUser;
	UtenteBean user= new UtenteBean();
	user.setCodiceUtente(1);
	try {
		allOrdersByUser=model.searchByCodeUser(user.getCodiceUtente(),1);
		System.out.println(allOrdersByUser);
		assertEquals(0, allOrdersByUser.size());

		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
	
	@Test
	public void TestSearchProdottoDaTitolo(){
		ProdottiDM model1 = new ProdottiDM();
		try {
			Collection<ProdottiBean> prodotti =model1.searchProdottoDaTitolo("UnTitolo");
			//assertEquals(0, prodotti.size());
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void TestGetAllProdotti(){
		ProdottiDM model1 = new ProdottiDM();
		try {
			Collection<ProdottiBean> collection = model1.getAllProdotti(null, 1);
			
			assertEquals(2, collection.size());
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void TestSearchProdottoByCodice(){
		ProdottiDM model1 = new ProdottiDM();
		try {
			ProdottiBean prodotto = model1.searchProdottoByCodice(1);
			assertEquals(0, prodotto.getCodiceProdotto());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void TestGetAllGameByGenere(){
		ProdottiDM model1 = new ProdottiDM();
		try {
			Collection<ProdottiBean> prodotti = model1.getAllGameByGenere("fps");
			//assertEquals(0, prodotti.size());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void TestInsertNuovoProdotto(){
		ProdottiDM model1 = new ProdottiDM();
		ProdottiBean prodotto = new ProdottiBean();
		
		prodotto.setCodicePegi("12+");
		prodotto.setCodiceProdotto(3);
		prodotto.setDescrizione("blalala");
		prodotto.setDisponibilit�(12);
		prodotto.setGenere("fps");
		prodotto.setImmagine("frefrfreferh9");
		prodotto.setPrezzo(1);
		prodotto.setProduttore("unProduttore");
		prodotto.setTitolo("UnTitolo");
		
		try {
			model1.insertNuovoProdotto(prodotto);
			assertEquals(3, prodotto.getCodiceProdotto());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void TestDeleteProdotto(){
		ProdottiDM model1 = new ProdottiDM();
		try {
			model1.deleteProdotto(1);
			assertFalse(model1.deleteProdotto(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}