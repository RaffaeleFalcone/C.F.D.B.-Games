function validateUser(){
	var action = document.aggiornaUtente.action.value;
	var oldPass = document.aggiornaUtente.oldPass.value;
	var newPass = document.aggiornaUtente.newPass.value;
	var newPass2 = document.aggiornaUtente.newPass2.value;
	var flag = true;
	
	if(action!="aggiornaUtente"){
		flag = false;
	}
	
	if (oldPass==null || oldPass ==""){
		document.getElementById("oldPass").style.borderColor = "red";
		flag= false;
		 alert("Password di conferma errata o non inserita");
	}
	
	if(newPass!=newPass2 || newPass==null || newPass2==null){
		document.getElementById("newPass").style.borderColor ="red";
		document.getElementById("newPass2").style.borderColor ="red";
		flag=false;
	}
	
	if(flag==true){
		document.getElementById("aggiornaUtente").submit();
		window.location.replace('/Login.jsp');
	}
	
	else {
		alert("aggiornamento fallito! ");
		
	}
}