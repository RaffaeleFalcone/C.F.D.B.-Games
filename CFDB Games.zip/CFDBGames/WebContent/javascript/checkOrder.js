function checkOrder(){
	var carta = document.getElementById("numCard").value;
	var flag = true;
	if(carta != 13){
		document.getElementById("numCard").style.bordereColor = "red";
		flag = false;
		alert("Numero carta non valido");
	}
	
	if(flag==true){
		document.getElementById("inviaOrdine").submit();
		alert("Acquisto Effettuato");
		window.location.replace('/AreaUtente.jsp');
	}
	
	
}