function validate(){
	
	var action = document.getElementById("action").value;
	
	var username = document.getElementById("username").value;
	var nome = document.getElementById("Nome").value;
	var cognome = document.getElementById("Cognome").value;
	var citta = document.getElementById("citta").value;
	var via = document.getElementById("via").value;
	var ncivico = document.getElementById("numero_civico").value;
	var email = document.getElementById("email").value;
	var password = document.getElementById("pass").value;
	var flag = true;
	
	if(action!="insert"){
		flag=false;
	}
	
	
	if(username==null || username=="" ){
		document.getElementById("username").style.borderColor = "red";
		flag=false;
	}
	if(nome==null || nome==""){
		document.getElementById("Nome").style.borderColor = "red";
		flag=false;
	}
	if(cognome==null || cognome==""){
		document.getElementById("Cognome").style.borderColor = "red";
		flag=false;
	}

	if(citta==null || citta==""){
		document.getElementById("citta").style.borderColor = "red";
		flag=false;
	}
	if(via==null || via==""){
		document.getElementById("via").style.borderColor = "red";
		flag=false;
	}
	if(ncivico<=0 || ncivico==null || ncivico=="" || ncivico=="Numero civico"){
		document.getElementById("numero_civico").style.borderColor = "red";
		flag=false;
	}
	if(email==null || email=="" || !(validateEmail(email))){
		document.getElementById("email").style.borderColor = "red";
		flag=false;
	}
	
	if(password==null || password==""){
		document.getElementById("pass").style.borderColor = "red";
		flag=false;
	}
	
	
	if(flag==true){
		document.getElementById("newUser").submit();
	}
	
	

}

	function validateEmail(email){
		var re =/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		return re.test(email);
	}
/**
 * 
 */